# aPersona Identity Manager — Multi-Tenant Platform

> Pre-built release artifacts for deploying aPersona Identity Manager to your AWS account.

## Prerequisites

- **AWS Account** with admin access
- **AWS CLI** v2 configured with credentials (`aws configure`)
- **Node.js** v22+ (see `.nvmrc`)
- **npm** v9+
- **jq** (JSON processor)
- **A registered domain** in Route 53

## Quick Start

```bash
# 1. Clone this repository
git clone https://github.com/kcsapersona/aPersona-Identity_Multi-Tenant_Install.git
cd amfa-mt-release

# 2. Configure your deployment
#    Edit tenants-config.json with your settings:
#    - deploymentName: unique name for your deployment
#    - rootDomainName: your Route 53 domain
#    - awsRegion: target AWS region
#    - adminEmail: super admin email address
#    - asmPortalUrl: ASM portal URL (provided by aPersona)
#    - asmServiceUrl: ASM service URL (provided by aPersona)
vi tenants-config.json

# 3. Run the installer
./install-multi-tenants.sh

# Installation takes 45-60 minutes
```

## Configuration Reference (`tenants-config.json`)

| Field | Description | Required |
|-------|-------------|----------|
| `deploymentName` | Unique deployment identifier | Yes |
| `rootDomainName` | Your Route 53 hosted domain | Yes |
| `awsRegion` | AWS region to deploy to | Yes |
| `adminEmail` | Super admin email | Yes |
| `asmPortalUrl` | ASM Portal URL | Yes |
| `asmServiceUrl` | ASM Service URL | Yes |
| `hostedZoneId` | Route 53 Hosted Zone ID (auto-detected if blank) | No |

## Uninstalling

```bash
./uninstall.sh
```

This will remove all AWS resources created by the installer.

## Directory Structure

```
├── amfa-service-multi-tenants/      # Pre-built identity service
├── amfa-admin-portal-multi-tenants/ # Pre-built admin portal
├── install-multi-tenants.sh         # Main installer
├── uninstall.sh                     # Uninstaller
├── tenants-config.json              # Configuration template
├── VERSION                          # Current version
├── SHA256SUMS                       # Integrity checksums
├── NOTICE                           # Third-party license notices
└── README.md                        # This file
```

## Verifying Integrity

```bash
# Verify release integrity using SHA256 checksums
sha256sum -c SHA256SUMS
```

## Troubleshooting

- **CDK bootstrap errors**: Ensure your AWS account is bootstrapped: `npx cdk bootstrap aws://ACCOUNT/REGION`
- **Domain not found**: Verify your domain's Route 53 hosted zone exists
- **Permission errors**: Ensure your AWS credentials have admin access
- **Node version**: Use Node.js v22+ (`nvm use 22`)

## Support

For deployment assistance, contact aPersona support.

---
*Built from source. Do NOT edit files in this repository directly.*
